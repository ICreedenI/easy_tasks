# PAKET
**contains to_precision by :**
- **William Rusnack github.com/BebeSparkelSparkel linkedin.com/in/williamrusnack williamrusnack@gmail.com**
- **Eric Moyer github.com/epmoyer eric@lemoncrab.com**
- **Thomas Hladish https://github.com/tjhladish tjhladish@utexas.edu**

Normal python class tasks like sorting, closet/furthest value, dublicates, ...